List<List<dynamic>> fillMissingValues(List<List<dynamic>> tableData) {
  List<List<dynamic>> filledTableData =
      tableData.map((row) => List.from(row)).toList();

  for (int colIndex = 0; colIndex < filledTableData[0].length; colIndex++) {
    List<dynamic> columnValues =
        filledTableData.map((row) => row[colIndex]).toList();

    List<int> emptyCellIndices = [];
    for (int rowIndex = 0; rowIndex < columnValues.length; rowIndex++) {
      if (columnValues[rowIndex].toString().isEmpty) {
        emptyCellIndices.add(rowIndex);
      }
    }

    double sum = 0;
    int count = 0;
    for (int rowIndex = 0; rowIndex < columnValues.length; rowIndex++) {
      if (columnValues[rowIndex] != null && columnValues[rowIndex] is num) {
        sum += columnValues[rowIndex];
        count++;
      }
    }

    double average = count > 0 ? sum / count : 0;

    for (int emptyIndex in emptyCellIndices) {
      if (filledTableData[emptyIndex][colIndex] == null ||
          filledTableData[emptyIndex][colIndex] is! num) {
        filledTableData[emptyIndex][colIndex] = average.toStringAsFixed(4);
      }
    }
  }

  return filledTableData;
}
