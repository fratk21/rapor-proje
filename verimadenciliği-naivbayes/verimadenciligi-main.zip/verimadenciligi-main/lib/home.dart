import 'dart:typed_data';
import 'package:cross_scroll/cross_scroll.dart';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:csv/csv.dart';
import 'package:verimadenciligi/func/datacorrection.dart';
import 'package:verimadenciligi/func/datanormalizyon.dart';
import 'package:verimadenciligi/func/getdata.dart';
import 'package:verimadenciligi/func/naivbayes.dart';
import 'package:verimadenciligi/func/naivbayeserror.dart';
import 'package:verimadenciligi/widgets/datatable.dart';
import 'package:verimadenciligi/widgets/datatablemap.dart';
import 'package:verimadenciligi/widgets/textfield.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String _filePath = '';
  List<List<dynamic>> _tableData = [];
  List<List<dynamic>> _correctiontableData = [];
  List<List<dynamic>> _normalizsayontableData = [];
  Map<String, dynamic> _normalizsayontableDataNaivbayes = {};
  Map<String, dynamic> _correctiontableDataNaivbayes = {};
  TextEditingController controllermin = TextEditingController();
  TextEditingController controllermax = TextEditingController();
  final FileOperations fileOperations = FileOperations();
  double totalError = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Veri Madenciliği Proje - Fırat Kaya'),
        actions: [
          TextButton.icon(
            onPressed: () async {
              await fileOperations.openFileExplorer();

              setState(() {
                _filePath = fileOperations.filePath;
                _tableData = fileOperations.tableData;
              });
            },
            icon: Icon(Icons.download_for_offline_rounded),
            label: Text("CSV FILE YUKLE"),
          ),
          SizedBox(width: 20),
        ],
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'File Name: ${_filePath.isEmpty ? "null" : _filePath}',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              if (_tableData.isNotEmpty)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _correctiontableData =
                                fillMissingValues(_tableData);
                          });
                        },
                        icon: Icon(Icons.check_box),
                        label: Text("Eksik verileri Tamamla")),
                    SizedBox(
                      width: 10,
                    ),
                    TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _normalizsayontableData = normalizeTable(
                              _correctiontableData,
                            );
                          });
                        },
                        icon: Icon(Icons.edit_attributes_outlined),
                        label: Text("Verileri Normalize Et")),
                    SizedBox(
                      width: 10,
                    ),
                    TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _correctiontableDataNaivbayes =
                                kCrossValidationNaiveBayes(
                                    _correctiontableData, 5);

                            _normalizsayontableDataNaivbayes =
                                kCrossValidationNaiveBayes(
                                    _normalizsayontableData, 5);
                            totalError = calculateMSE(
                                _correctiontableDataNaivbayes,
                                _normalizsayontableDataNaivbayes);
                          });
                        },
                        icon: Icon(Icons.roller_shades_sharp),
                        label: Text("Naive Bayes")),
                  ],
                ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_tableData.isNotEmpty)
                    Expanded(
                        child: Column(
                      children: [
                        Text("Orjinal Veri"),
                        DataTableWidget(data: _tableData),
                      ],
                    )),
                  if (_correctiontableData.isNotEmpty)
                    Expanded(
                        child: Column(
                      children: [
                        Text("Ortalama ile Tamamlanmış Veri"),
                        DataTableWidget(data: _correctiontableData),
                      ],
                    )),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              if (_normalizsayontableData.isNotEmpty)
                Column(
                  children: [
                    Text("Normalize olmuş Veri"),
                    DataTableWidget(data: _normalizsayontableData),
                  ],
                ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  if (_normalizsayontableDataNaivbayes.isNotEmpty)
                    Expanded(
                      child: Column(
                        children: [
                          Text("Normalize olmuş Verinin Naiv bayes çıktısı "),
                          CustomDataTableWidget(
                              data: _normalizsayontableDataNaivbayes),
                        ],
                      ),
                    ),
                  if (_correctiontableDataNaivbayes.isNotEmpty)
                    Expanded(
                      child: Column(
                        children: [
                          Text("Ham Verinin Naiv bayes çıktısı "),
                          CustomDataTableWidget(
                              data: _correctiontableDataNaivbayes),
                        ],
                      ),
                    ),
                ],
              ),
              if (_normalizsayontableDataNaivbayes.isNotEmpty)
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Container(
                        color: Colors.deepPurple,
                        child: Text(
                          "Hata Analiz Çıktısı",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      Container(
                        color: Colors.white,
                        child: Text("$totalError"),
                      )
                    ],
                  ),
                ),
              SizedBox(
                height: 50,
              )
            ],
          ),
        ),
      ),
    );
  }
}
