import 'package:cross_scroll/cross_scroll.dart';
import 'package:flutter/material.dart';

class DataTableWidget extends StatefulWidget {
  final List<List<dynamic>> data;

  DataTableWidget({required this.data});

  @override
  _DataTableWidgetState createState() => _DataTableWidgetState();
}

class _DataTableWidgetState extends State<DataTableWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxWidth: 800, maxHeight: 400),
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: CrossScroll(
        child: DataTable(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20))),
          columnSpacing: 12,
          headingRowColor: MaterialStateColor.resolveWith(
            (states) => Colors.deepPurple,
          ),
          headingTextStyle: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          dataRowHeight: 40,
          columns: [
            DataColumn(
              label: Text(
                'Sira',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            ...widget.data[0]
                .map(
                  (item) => DataColumn(
                    label: Container(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        item.toString(),
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    onSort: (columnIndex, ascending) {
                      setState(() {
                        widget.data.sort((a, b) => ascending
                            ? a[columnIndex].compareTo(b[columnIndex])
                            : b[columnIndex].compareTo(a[columnIndex]));
                      });
                    },
                  ),
                )
                .toList(),
          ],
          rows: widget.data
              .asMap()
              .entries
              .map(
                (entry) => DataRow(
                  cells: [
                    DataCell(
                      Container(
                        padding: EdgeInsets.all(8.0),
                        child: Text((entry.key + 1).toString()),
                      ),
                    ),
                    ...entry.value
                        .map(
                          (item) => DataCell(
                            Container(
                              padding: EdgeInsets.all(8.0),
                              child: Text(item.toString()),
                            ),
                          ),
                        )
                        .toList(),
                  ],
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}
