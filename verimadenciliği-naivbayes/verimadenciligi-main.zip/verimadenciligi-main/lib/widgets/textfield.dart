import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NumericTextField extends StatefulWidget {
  final TextEditingController controller;
  final String labelText;

  NumericTextField({required this.controller, required this.labelText});

  @override
  _NumericTextFieldState createState() => _NumericTextFieldState();
}

class _NumericTextFieldState extends State<NumericTextField> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      style: TextStyle(fontSize: 12),
      keyboardType: TextInputType.number,
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.digitsOnly,
      ],
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(10),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(2),
        ),
        hintText: widget.labelText,
        //   labelText: ,
      ),
    );
  }
}
