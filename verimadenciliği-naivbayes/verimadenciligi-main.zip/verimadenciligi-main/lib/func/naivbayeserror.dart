double calculateMSE(
    Map<String, dynamic> original, Map<String, dynamic> normalized) {
  List<dynamic> originalFolds = original['folds'];
  List<dynamic> normalizedFolds = normalized['folds'];

  int totalRows = 0;
  double totalSquaredError = 0;

  for (int i = 0; i < originalFolds.length; i++) {
    List<dynamic> originalActual = originalFolds[i]['actual'];
    List<dynamic> predictedActual = normalizedFolds[i]['actual'];

    for (int j = 0; j < originalActual.length; j++) {
      if (originalActual[j] is num && predictedActual[j] is num) {
        double error = (originalActual[j] - predictedActual[j]).abs();
        totalSquaredError += error * error;
        totalRows++;
      } else {
        print("beklenmedik hata: ${originalActual[j]} , ${predictedActual[j]}");
      }
    }
  }

  if (totalRows == 0) {
    print("Error:0");
    return 0.0;
  }

  double meanSquaredError = totalSquaredError / totalRows;
  return meanSquaredError;
}
