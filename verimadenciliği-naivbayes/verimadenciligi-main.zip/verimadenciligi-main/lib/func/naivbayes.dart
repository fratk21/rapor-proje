import 'dart:math' as math;

List<List<List<dynamic>>> kCrossValidation(List<List<dynamic>> data, int k) {
  int rowCount = data.length;
  int foldSize = (rowCount / k).floor();

  List<List<dynamic>> shuffledData = List.from(data);
  shuffledData.shuffle();

  List<List<List<dynamic>>> folds = [];
  for (int i = 0; i < k - 1; i++) {
    List<List<dynamic>> fold =
        shuffledData.sublist(i * foldSize, (i + 1) * foldSize);
    folds.add(fold);
  }

  folds.add(shuffledData.sublist((k - 1) * foldSize));

  return folds;
}

Map<String, dynamic> trainNaiveBayesModel(
    List<List<double>> data, List<dynamic> target) {
  Map<String, dynamic> model = {};
  List<dynamic> classes = Set.from(target).toList();

  for (dynamic classValue in classes) {
    List<List<double>> filteredData = [];
    for (int i = 0; i < target.length; i++) {
      if (target[i] == classValue) {
        filteredData.add(data[i]);
      }
    }

    model[classValue.toString()] = {};

    for (int col = 0; col < filteredData[0].length; col++) {
      List<double> columnValues = filteredData.map((row) => row[col]).toList();

      if (columnValues.isEmpty ||
          columnValues.every((value) => value == null)) {
        model[classValue.toString()]['mean_$col'] = 0.0;
        model[classValue.toString()]['std_$col'] = 0.0;
      } else {
        model[classValue.toString()]['mean_$col'] =
            columnValues.reduce((a, b) => a + b) / columnValues.length;
        model[classValue.toString()]['std_$col'] =
            standardDeviation(columnValues);
      }
    }
  }

  return model;
}

double standardDeviation(List<double> values) {
  double mean = values.reduce((a, b) => a + b) / values.length;
  double variance =
      values.map((value) => math.pow(value - mean, 2)).reduce((a, b) => a + b) /
          values.length;
  return math.sqrt(variance);
}

String predictNaiveBayes(Map<String, dynamic> model, List<double> data) {
  double maxProbability = double.negativeInfinity;
  String predictedClass = '';

  for (String classValue in model.keys) {
    double classProbability = 1.0;

    for (int col = 0; col < data.length; col++) {
      double mean = model[classValue]['mean_$col'];
      double std = model[classValue]['std_$col'];
      double x = data[col];

      if (x == null) {
        mean = 0.0;
        std = 1.0;
      }

      double exponent = -math.pow(x - mean, 2) / (2 * math.pow(std, 2));
      double probability =
          1 / (std * math.sqrt(2 * math.pi)) * math.exp(exponent);

      classProbability *= probability;
    }

    if (classProbability > maxProbability) {
      maxProbability = classProbability;
      predictedClass = classValue;
    }
  }

  return predictedClass;
}

Map<String, dynamic> kCrossValidationNaiveBayes(
    List<List<dynamic>> data, int k) {
  List<List<List<dynamic>>> folds = kCrossValidation(data, k);
  List<Map<String, dynamic>> foldResults = [];

  for (int i = 0; i < k; i++) {
    List<List<dynamic>> testFold = folds[i];
    List<List<dynamic>> trainFolds = [];

    for (int j = 0; j < k; j++) {
      if (j != i) {
        trainFolds.addAll(folds[j]);
      }
    }

    List<List<double>> trainData = [];
    List<dynamic> trainTarget = [];

    for (List<dynamic> row in trainFolds) {
      List<double> processedRow = row.sublist(1).map((value) {
        if (value == null || value is! num) {
          return 0.0;
        }
        return value.toDouble();
      }).toList();

      trainData.add(processedRow);
      trainTarget.add(row[0]);
    }

    Map<String, dynamic> classStats =
        trainNaiveBayesModel(trainData, trainTarget);

    List<dynamic> predictions = [];

    for (List<dynamic> row in testFold) {
      List<double> processedRow = row.sublist(1).map((value) {
        if (value == null || value is! num) {
          return 0.0;
        }
        return value.toDouble();
      }).toList();

      dynamic prediction = predictNaiveBayes(classStats, processedRow);
      predictions.add(prediction);
    }

    foldResults.add({
      'actual': testFold.map((row) => row[0]).toList(),
      'predicted': predictions,
    });
  }

  return {'folds': foldResults};
}
