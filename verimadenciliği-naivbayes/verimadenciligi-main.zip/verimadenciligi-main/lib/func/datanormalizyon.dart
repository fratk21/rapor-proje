List<List<double>> normalizeTable(List<List<dynamic>> table) {
  List<List<dynamic>> originalTable =
      table.map((row) => List.from(row)).toList();

  List<List<double>> normalizedTable = [];

  int rowCount = originalTable.length;
  int colCount = originalTable.isEmpty ? 0 : originalTable[0].length;

  for (int colIndex = 0; colIndex < colCount; colIndex++) {
    List<dynamic> columnValues =
        originalTable.map((row) => row[colIndex]).toList();

    List<double> numericValues = columnValues
        .whereType<num?>()
        .where((value) => value != null)
        .map<double>((value) => value!.toDouble())
        .toList();

    if (numericValues.isEmpty) {
      normalizedTable.add(List.filled(rowCount, 0.0));
      continue;
    }

    double min = numericValues.reduce((a, b) => a < b ? a : b);
    double max = numericValues.reduce((a, b) => a > b ? a : b);

    List<double> normalizedColumn = originalTable.map((row) {
      dynamic value = row[colIndex];
      if (value is num) {
        return (value - min) / (max - min);
      }
      return 0.0;
    }).toList();

    normalizedTable.add(normalizedColumn);
  }

  normalizedTable = List.generate(
    rowCount,
    (rowIndex) => List.generate(
      colCount,
      (colIndex) => normalizedTable[colIndex][rowIndex],
    ),
  );

  return normalizedTable;
}
