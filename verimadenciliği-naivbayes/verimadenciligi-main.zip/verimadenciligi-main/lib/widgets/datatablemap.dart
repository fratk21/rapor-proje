import 'package:cross_scroll/cross_scroll.dart';
import 'package:flutter/material.dart';

class CustomDataTableWidget extends StatelessWidget {
  final Map<String, dynamic> data;

  CustomDataTableWidget({required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxWidth: 800, maxHeight: 400),
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: CrossScroll(
          child: DataTable(
        decoration:
            BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(20))),
        columnSpacing: 12,
        headingRowColor: MaterialStateColor.resolveWith(
          (states) => Colors.deepPurple,
        ),
        headingTextStyle: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
        dataRowHeight: 40,
        columns: [
          DataColumn(label: Text('Fold')),
          DataColumn(label: Text('Actual')),
          DataColumn(label: Text('Predicted')),
        ],
        rows: List.generate(data['folds'].length, (index) {
          var fold = data['folds'][index];
          var actual = fold['actual'];
          var predicted = fold['predicted'];

          return DataRow(
            cells: [
              DataCell(Text('Fold $index')),
              DataCell(Text('$actual')),
              DataCell(Text('$predicted')),
            ],
          );
        }),
      )),
    );
  }
}
