import 'dart:typed_data';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:csv/csv.dart';

class FileOperations {
  String _filePath = '';
  List<List<dynamic>> _tableData = [];

  Future<void> openFileExplorer() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv'],
      );

      if (result != null) {
        Uint8List bytes = result.files.single.bytes!;
        _filePath = result.files.single.name!;

        if (_filePath.endsWith('.xlsx')) {
          await readExcelFile(bytes);
        } else if (_filePath.endsWith('.csv')) {
          await readCSVFile(bytes);
        }
      }
    } on Exception catch (e) {
      print('Error: $e');
    }
  }

  Future<void> readExcelFile(Uint8List bytes) async {
    try {
      var excel = Excel.decodeBytes(bytes);

      for (var table in excel.tables.keys) {
        _tableData = excel.tables[table]!.rows;
      }
    } catch (e) {
      print('Excel Read Error: $e');
    }
  }

  Future<void> readCSVFile(Uint8List bytes) async {
    try {
      String csvData = String.fromCharCodes(bytes);
      List<List<dynamic>> csvTable = CsvToListConverter().convert(csvData);

      _tableData = csvTable;
    } catch (e) {
      print('CSV Read Error: $e');
    }
  }

  String get filePath => _filePath;
  List<List<dynamic>> get tableData => _tableData;
}
